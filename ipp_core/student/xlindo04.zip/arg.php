<?php
/** 
 * autor: Jan Lindovsky
 */ 
namespace IPP\Student;

use IPP\Core\Exception\InternalErrorExceptio;

class arg
{
    public string $type;
    public string $val;
}
