<?php
/** 
 * autor: Jan Lindovsky
 */ 
namespace IPP\Student;

use IPP\Core\Exception\InternalErrorException;

class inst
{

    public string $opcode;

    /**
     * @var arg[] Array of arg objects
     */
    public array $args;
}
